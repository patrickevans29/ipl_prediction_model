A model that can be used to predict the outcome of IPL cricket matches. 
